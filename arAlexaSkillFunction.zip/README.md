_________
 S T O P
=========
THIS IS NOT THE ENDPOINT FOR THE ALEXA SKILL. 

YOU MUST USE THE ALEXA-DEVELOPER-CONSOLE-HOSTED-CODEBASE. Because otherwise the DynamoDB stuff for 
checking the user's answer to the "are you blind?" question will not work.

So, do NOT edit this code and think you're updating the alexa skill. Just stop.

-------

Source code location: index.js
look there for more documentation, notes, etc. 

(unused) endpoint: arn:aws:lambda:us-east-1:487340227683:function:playAudioReader:LIVE

actional endpoint: arn:aws:lambda:us-east-1:004338474798:function:8f10c20e-4de7-43de-b1b9-e6a3e1da1bfd:Release_5

skill ID: amzn1.ask.skill.8f10c20e-4de7-43de-b1b9-e6a3e1da1bfd


